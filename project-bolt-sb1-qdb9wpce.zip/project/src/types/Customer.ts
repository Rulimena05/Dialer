export interface Customer {
  id: string;
  caseId: string;
  customerName: string;
  phoneNumber: string;
  handel: string;
}