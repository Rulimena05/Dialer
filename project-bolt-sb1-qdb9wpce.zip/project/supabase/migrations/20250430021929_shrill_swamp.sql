/*
  # Fix campaign policies and permissions

  1. Changes
    - Update RLS policies for campaigns table
    - Add missing permissions for campaign management
    - Fix agent access policies

  2. Security
    - Enable RLS on campaigns table
    - Add policies for admin and agent access
    - Ensure proper role-based access control
*/

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Admins can manage campaigns" ON campaigns;
DROP POLICY IF EXISTS "Agents can view assigned campaigns" ON campaigns;

-- Create new policies with fixed permissions
CREATE POLICY "Admins can manage campaigns"
ON campaigns
FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM user_roles ur
    JOIN roles r ON r.id = ur.role_id
    WHERE ur.user_id = auth.uid() AND r.name = 'admin'
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM user_roles ur
    JOIN roles r ON r.id = ur.role_id
    WHERE ur.user_id = auth.uid() AND r.name = 'admin'
  )
);

CREATE POLICY "Agents can view assigned campaigns"
ON campaigns
FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM campaign_assignments ca
    WHERE ca.campaign_id = campaigns.id 
    AND ca.agent_id = auth.uid()
  )
);