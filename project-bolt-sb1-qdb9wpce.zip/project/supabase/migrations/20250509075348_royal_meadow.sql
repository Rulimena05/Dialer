/*
  # Initial database setup for Auto Dial System

  1. New Tables
    - `customers`
      - `id` (uuid, primary key)
      - `case_id` (text)
      - `customer_name` (text)
      - `phone_number` (text)
      - `handel` (text)
      - `created_at` (timestamp)
    
    - `call_history`
      - `id` (uuid, primary key)
      - `customer_id` (uuid, references customers)
      - `call_date` (timestamp)
      - `start_time` (timestamp)
      - `end_time` (timestamp)
      - `duration` (integer)
      - `status` (text)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on all tables
    - Add policies for data access
*/

-- Create customers table
CREATE TABLE IF NOT EXISTS customers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  case_id text NOT NULL,
  customer_name text,
  phone_number text NOT NULL,
  handel text,
  created_at timestamptz DEFAULT now()
);

-- Create call_history table
CREATE TABLE IF NOT EXISTS call_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id uuid REFERENCES customers ON DELETE CASCADE,
  call_date timestamptz DEFAULT now(),
  start_time timestamptz NOT NULL,
  end_time timestamptz,
  duration integer DEFAULT 0,
  status text CHECK (status IN ('Answer', 'Not Answer', 'Not Active', 'Voice Mail', 'in progress', 'Error')),
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE call_history ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Enable read access for all users" ON customers FOR SELECT USING (true);
CREATE POLICY "Enable insert for all users" ON customers FOR INSERT WITH CHECK (true);

CREATE POLICY "Enable read access for all users" ON call_history FOR SELECT USING (true);
CREATE POLICY "Enable insert for all users" ON call_history FOR INSERT WITH CHECK (true);
CREATE POLICY "Enable update for all users" ON call_history FOR UPDATE USING (true) WITH CHECK (true);