/*
  # Add authentication and campaign management

  1. New Tables
    - `roles`
      - `id` (uuid, primary key)
      - `name` (text, unique) - 'admin' or 'agent'
      - `created_at` (timestamp)
    
    - `user_roles`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `role_id` (uuid, references roles)
      - `created_at` (timestamp)
    
    - `campaigns`
      - `id` (uuid, primary key)
      - `name` (text)
      - `description` (text)
      - `created_at` (timestamp)
      - `created_by` (uuid, references auth.users)
      - `status` (text) - 'active' or 'inactive'
    
    - `campaign_assignments`
      - `id` (uuid, primary key)
      - `campaign_id` (uuid, references campaigns)
      - `agent_id` (uuid, references auth.users)
      - `created_at` (timestamp)
      - `assigned_by` (uuid, references auth.users)
      - `status` (text) - 'pending', 'in_progress', 'completed'

  2. Security
    - Enable RLS on all tables
    - Add policies for admin and agent access
*/

-- Create roles table
CREATE TABLE IF NOT EXISTS roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE roles ENABLE ROW LEVEL SECURITY;

-- Insert default roles
INSERT INTO roles (name) VALUES ('admin'), ('agent');

-- Create user_roles table
CREATE TABLE IF NOT EXISTS user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users NOT NULL,
  role_id uuid REFERENCES roles NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, role_id)
);

ALTER TABLE user_roles ENABLE ROW LEVEL SECURITY;

-- Create campaigns table
CREATE TABLE IF NOT EXISTS campaigns (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text,
  created_at timestamptz DEFAULT now(),
  created_by uuid REFERENCES auth.users NOT NULL,
  status text NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive'))
);

ALTER TABLE campaigns ENABLE ROW LEVEL SECURITY;

-- Create campaign_assignments table
CREATE TABLE IF NOT EXISTS campaign_assignments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  campaign_id uuid REFERENCES campaigns ON DELETE CASCADE NOT NULL,
  agent_id uuid REFERENCES auth.users NOT NULL,
  created_at timestamptz DEFAULT now(),
  assigned_by uuid REFERENCES auth.users NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'in_progress', 'completed'))
);

ALTER TABLE campaign_assignments ENABLE ROW LEVEL SECURITY;

-- Add campaign_id to customers table
ALTER TABLE customers ADD COLUMN campaign_id uuid REFERENCES campaigns ON DELETE CASCADE;

-- Policies for roles
CREATE POLICY "Anyone can read roles" ON roles
  FOR SELECT TO authenticated
  USING (true);

-- Policies for user_roles
CREATE POLICY "Admins can manage user roles" ON user_roles
  FOR ALL TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles ur
      JOIN roles r ON r.id = ur.role_id
      WHERE ur.user_id = auth.uid() AND r.name = 'admin'
    )
  );

CREATE POLICY "Users can view their own roles" ON user_roles
  FOR SELECT TO authenticated
  USING (user_id = auth.uid());

-- Policies for campaigns
CREATE POLICY "Admins can manage campaigns" ON campaigns
  FOR ALL TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles ur
      JOIN roles r ON r.id = ur.role_id
      WHERE ur.user_id = auth.uid() AND r.name = 'admin'
    )
  );

CREATE POLICY "Agents can view assigned campaigns" ON campaigns
  FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM campaign_assignments ca
      WHERE ca.campaign_id = id AND ca.agent_id = auth.uid()
    )
  );

-- Policies for campaign_assignments
CREATE POLICY "Admins can manage assignments" ON campaign_assignments
  FOR ALL TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles ur
      JOIN roles r ON r.id = ur.role_id
      WHERE ur.user_id = auth.uid() AND r.name = 'admin'
    )
  );

CREATE POLICY "Agents can view their assignments" ON campaign_assignments
  FOR SELECT TO authenticated
  USING (agent_id = auth.uid());

-- Update customers policies
DROP POLICY IF EXISTS "Users can insert their own customers" ON customers;
DROP POLICY IF EXISTS "Users can update their own customers" ON customers;
DROP POLICY IF EXISTS "Users can delete their own customers" ON customers;
DROP POLICY IF EXISTS "Users can view their own customers" ON customers;

CREATE POLICY "Admins can manage all customers" ON customers
  FOR ALL TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles ur
      JOIN roles r ON r.id = ur.role_id
      WHERE ur.user_id = auth.uid() AND r.name = 'admin'
    )
  );

CREATE POLICY "Agents can view assigned customers" ON customers
  FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM campaign_assignments ca
      WHERE ca.campaign_id = customers.campaign_id 
      AND ca.agent_id = auth.uid()
    )
  );

-- Update call_history policies
DROP POLICY IF EXISTS "Users can insert their own call history" ON call_history;
DROP POLICY IF EXISTS "Users can update their own call history" ON call_history;
DROP POLICY IF EXISTS "Users can view their own call history" ON call_history;

CREATE POLICY "Admins can view all call history" ON call_history
  FOR SELECT TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM user_roles ur
      JOIN roles r ON r.id = ur.role_id
      WHERE ur.user_id = auth.uid() AND r.name = 'admin'
    )
  );

CREATE POLICY "Agents can manage their call history" ON call_history
  FOR ALL TO authenticated
  USING (user_id = auth.uid());